/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/21 10:50:55 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/21 22:19:41 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FRAGTRAP_H
# define FRAGTRAP_H

# include <string>
# include "ClapTrap.hpp"

class FragTrap: public ClapTrap
{
	private:
		static int						_attack_number;
		static unsigned int (FragTrap::*_attacks[])(std::string const &target);

	public:
		FragTrap(std::string name);
		~FragTrap(void);
		FragTrap(FragTrap const &src);

		FragTrap		&operator=(FragTrap const &rhs);

		unsigned int	vaulthunter_dot_exe(std::string const &target);

		unsigned int	kill1(std::string const &target);
		unsigned int	kill2(std::string const &target);
		unsigned int	kill3(std::string const &target);
		unsigned int	kill4(std::string const &target);
		unsigned int	kill5(std::string const &target);
};

#endif