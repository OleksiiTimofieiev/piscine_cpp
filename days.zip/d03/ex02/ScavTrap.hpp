/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/21 18:10:45 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/22 16:16:15 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCAVTRAP_H
# define SCAVTRAP_H

# include <string>
# include "ClapTrap.hpp"

class ScavTrap: public ClapTrap
{
	private:
		static int					_challenge_number;
		static std::string			_challenges[];

	public:
		ScavTrap(std::string name);
		~ScavTrap(void);
		ScavTrap(ScavTrap const &src);

		ScavTrap		&operator=(ScavTrap const &rhs);
		void			challengeNewcomer(std::string const &target);
};

#endif