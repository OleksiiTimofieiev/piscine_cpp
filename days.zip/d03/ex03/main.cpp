/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/06/18 11:38:27 by ncoden            #+#    #+#             */
/*   Updated: 2018/06/21 23:07:38 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FragTrap.hpp"
#include "ScavTrap.hpp"
#include "NinjaTrap.hpp"

#include <iostream>

int				main(void)
{
	std::cout << "\033[1;33mCreatio ex nihilo:\033[0m" << std::endl;

	ScavTrap	Palpatine("CheeseBurger");
	FragTrap	Enakin("DoubleCheeseBurger");
	NinjaTrap	ninja("you did not see anythin : )))))))");

	std::cout << "\033[1;33mSome war in Japan: act 1\033[0m" << std::endl;

	Palpatine.rangedAttack(Enakin.getName());
	Enakin.takeDamage(Palpatine.getRangedAttackDamage());

	Enakin.meleeAttack(Palpatine.getName());
	Palpatine.takeDamage(Enakin.getMeleeAttackDamage());

	Palpatine.meleeAttack(Enakin.getName());
	Enakin.takeDamage(Palpatine.getMeleeAttackDamage());

	Enakin.rangedAttack(Palpatine.getName());
	Palpatine.takeDamage(Enakin.getRangedAttackDamage());

	Enakin.beRepaired(50);

	Enakin.rangedAttack(Palpatine.getName());
	Palpatine.takeDamage(Enakin.getRangedAttackDamage());

	Palpatine.challengeNewcomer(ninja.getName());
	Palpatine.challengeNewcomer(ninja.getName());
	Palpatine.challengeNewcomer(ninja.getName());


	std::cout << "\033[1;33mSome war in Japan: act 2\033[0m" << std::endl;

	ninja.ninjaShoebox(Palpatine);
	ninja.ninjaShoebox(Palpatine);

	std::cout << "\033[1;33mSome war in Japan: act 4: EL MAHACH\033[0m" << std::endl;


	Palpatine.takeDamage(Enakin.vaulthunter_dot_exe(Palpatine.getName()));
	Palpatine.takeDamage(Enakin.vaulthunter_dot_exe(Palpatine.getName()));

	std::cout << "\033[1;33mSome war in Japan: act 5: ninjaShoebox\033[0m" << std::endl;

	ninja.ninjaShoebox(Enakin);
	ninja.ninjaShoebox(Enakin);

	std::cout << "\033[1;33mSome war in Japan: act 6: fatality\033[0m" << std::endl;

	Enakin.takeDamage(200);

	std::cout << "\033[1;33mFikus:\033[0m" << std::endl;
}
