for d in */; do
    echo "$d"
	make -C $d
done

/Applications/Sublime\ Text.app/Contents/SharedSupport/bin/subl ./
