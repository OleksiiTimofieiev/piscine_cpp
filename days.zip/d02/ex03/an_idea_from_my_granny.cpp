/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   an_idea_from_my_granny.cpp                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/21 10:43:42 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/21 10:46:54 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

int main(void)
{
	std::cout << "Granny`s words:\n\nanyway any class will have the namespace to work with the specific kind of a variable.\nit is cooler to have a lot of privates as a default for the future inheritance operations.\nand my granny seems to think that to have privates is much simplier after two hours of explanations :)" << std::endl;

	return 0;
}
