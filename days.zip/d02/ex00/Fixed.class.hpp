/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/20 16:32:09 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 16:32:10 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef FIXED_CLASS_H
# define FIXED_CLASS_H

#include <iostream>

class Fixed {

public :
    Fixed(void);

    Fixed(int const raw);

    Fixed(Fixed const &src);

    ~Fixed(void);

    Fixed &operator=(Fixed const &rhs);

    void setRawBits(int const raw);

    int getRawBits(void) const;

private:
    const int fractionalbBits;
    int rawBits;

};

#endif