/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/18 11:10:34 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/18 11:10:36 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Contact.class.hpp"

#include <iostream>
#include <cstdlib>
#include <string>

void	print_the_line_aim(int i)
{
	if (i == 0)
		std::cout << "Please, enter the first name" << std::endl;
	else if (i == 1)
		std::cout << "Please, enter the last_name" << std::endl;
	else if (i == 2)
		std::cout << "Please, enter the nickname" << std::endl;
	else if (i == 3)
		std::cout << "Please, enter the login" << std::endl;
	else if (i == 4)
		std::cout << "Please, enter the postal_address" << std::endl;
	else if (i == 5)
		std::cout << "Please, enter the email_address" << std::endl;
	else if (i == 6)
		std::cout << "Please, enter the phone_number" << std::endl;
	else if (i == 7)
		std::cout << "Please, enter the birthday_date" << std::endl;
	else if (i == 8)				
		std::cout << "Please, enter the favourite_meal" << std::endl;
	else if (i == 9)
		std::cout << "Please, enter the underwear_color" << std::endl;
	else if (i == 10)
		std::cout << "Please, enter the darkest_secret" << std::endl;
}

void	fill_the_buffer(std::string var[11])
{
	int i = 0;
	std::cout << "------------------ *** ----------------------" << std::endl;

	while (i < 11)
	{
		print_the_line_aim(i);

		if(!(std::getline(std::cin, var[i])))
			exit (0);

		if (var[i] == "")
			std::cout << "\033[1;31mNo data have been indicated. Please, enter the data.\033[0m" << std::endl;
		else
			i++;
	}

	std::cout << "------------------ *** ----------------------" << std::endl << std::endl;
}

void	displayDetails(Contact	Instances[8], int element)
{
	std::cout << "+-------------------------------------------+" << std::endl;
	std::cout << "\033[1;36m|     INDEX\033[0m";
	std::cout << "\033[1;36m|    F_NAME\033[0m";
	std::cout << "\033[1;36m|    L_NAME\033[0m";
	std::cout << "\033[1;36m|    N_NAME\033[0m" << '|' << std::endl;
	std::cout << "+-------------------------------------------+" << std::endl;

	
	int i = 0;

	while (i < element)
	{
		Instances[i].displaySpecial();
		std::cout << "+-------------------------------------------+" << std::endl;
		i++;
	}

	std::cout << "\033[1;35mPlease, select the necessary index.\033[0m" << std::endl;

	i = 0;

	std::string index_input;
	if(!(std::getline(std::cin, index_input)))
		exit (0) ;

	while (i < element)
	{

		if (Instances[i].getIndex().compare(index_input) == 0)
		{
			system("clear");
			Instances[i].displayOneLine();
			return ;
		}
		else if (index_input == "EXIT")
			exit (0);
		i++;
	}
	std::cout << "\033[1;31mNecessary index was not found. Please, try SEARCH command one more time.\033[0m" << std::endl;
}

int		main(void)
{
	int element = 0;

	std::string command_input;

	std::string input[8];

	std::string user_input[11];

	Contact	Instances[8];

	while (1)
	{
		std::cout << "\033[1;32mPlease, select the necessary command.\033[0m" << std::endl;

		if(!(std::getline(std::cin, command_input)))
			return (0);
		if (command_input.compare("EXIT") == 0)
			return (0);
		else if (command_input.compare("ADD") == 0 && element < 8)
		{
			fill_the_buffer(user_input);
			Instances[element].setValues(	user_input[0], user_input[1], user_input[2], user_input[3], user_input[4],
											user_input[5], user_input[6], user_input[7], user_input[8], user_input[9], 
											user_input[10], &element);
			element++;
		}
		else if (command_input.compare("ADD") == 0 && element > 7)
			std::cout << "\033[1;35mPhonebook is full. No more input is acceptable.\033[0m" << std::endl;
		else if (command_input.compare("SEARCH") == 0 && element != 0)
			displayDetails(Instances, element);
		else if (command_input.compare("SEARCH") == 0 && element == 0)
			std::cout << "\033[1;35mThe database is empty. Please, fill it in.\033[0m" << std::endl;
	}
	return 0;
}
