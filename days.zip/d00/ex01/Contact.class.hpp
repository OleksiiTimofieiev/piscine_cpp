/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Contact.class.hpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/18 17:13:40 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/18 17:13:42 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONTACT_CLASS_HPP
#define CONTACT_CLASS_HPP

#include <iostream>

class Contact {

private:

	std::string	index;
	std::string first_name;
	std::string last_name;
	std::string nickname;
	std::string login;
	std::string postal_address;
	std::string email_address;
	std::string phone_number;
	std::string birthday_date;
	std::string favourite_meal;
	std::string underwear_color;
	std::string darkest_secret;

public:

	void			setValues(	const std::string & first_name, const std::string & last_name, const std::string & nickname, const std::string & login, const std::string & postal_address,
	  		 			const std::string & email_address, const std::string & phone_number, const std::string & birthday_date, const std::string & favourite_meal, const std::string & underwear_color,
	  					const std::string & darkest_secret, int *var );

	void			aspects(std::string & var);

	void			displaySpecial(void);

	void			displayOneLine(void);

	std::string		getIndex(void);
};

#endif
