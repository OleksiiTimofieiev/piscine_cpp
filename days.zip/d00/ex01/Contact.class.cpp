/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Contact.class.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/18 17:13:28 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/18 17:13:29 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Contact.class.hpp"

void	Contact::setValues(	const std::string & first_name_, const std::string & last_name_, const std::string & nickname_, const std::string & login_, const std::string & postal_address_,
	  		 				const std::string & email_address_, const std::string & phone_number_, const std::string & birthday_date_, const std::string & favourite_meal_, const std::string & underwear_color_,
	  						const std::string & darkest_secret_, int *var )
{
	this->index 				= std::to_string((*var) + 1);
	this->first_name 			= first_name_;
	this->last_name 			= last_name_;
	this->nickname 				= nickname_;
	this->login 				= login_;
	this->postal_address 		= postal_address_;
	this->email_address 		= email_address_;
	this->phone_number 			= phone_number_;
	this->birthday_date 		= birthday_date_;
	this->favourite_meal 		= favourite_meal_;
	this->underwear_color 		= underwear_color_;
	this->darkest_secret 		= darkest_secret_;

	return ;
}

void	Contact::aspects(std::string & var)
{
	int print_space = 10;
	int length = var.length();
	int i = 0;
		
	std::cout << '|';
	if (length <= 10)
	{
		print_space -= length;
		while (print_space)
		{
			std::cout << ' ';
			print_space--;
		}
		std::cout << var;
	}
	else
	{
		while (i < 9)
			std::cout << var[i++];
		std::cout << '.';
	}
}

void	Contact::displaySpecial(void)
{
	aspects(this->index);
	aspects(this->first_name);
	aspects(this->last_name);
	aspects(this->nickname);

	std::cout << '|';
	std::cout << std::endl;
}

void	Contact::displayOneLine(void)
{
	std::cout << "\033[1;33mFirst_name:\033[0m" 				 << std::endl;
	std::cout << this->first_name 								 << std::endl;
	std::cout << "\033[1;33mLast_name:\033[0m" 					 << std::endl;	
	std::cout << this->last_name 			 					 << std::endl;		
	std::cout << "\033[1;33mNickname:\033[0m" 					 << std::endl;
	std::cout << this->nickname 								 << std::endl;		
	std::cout << "\033[1;33mLogin:\033[0m" 				 		 << std::endl;
	std::cout << this->login 				 					 << std::endl;			
	std::cout << "\033[1;33mPostal_address:\033[0m" 			 << std::endl;
	std::cout << this->postal_address  							 << std::endl;
	std::cout << "\033[1;33mEmail_address:\033[0m" 				 << std::endl;
	std::cout << this->email_address 							 << std::endl;
	std::cout << "\033[1;33mPhone_number:\033[0m" 				 << std::endl;
	std::cout << this->phone_number 							 << std::endl;
	std::cout << "\033[1;33mBirthday_date:\033[0m" 				 << std::endl;
	std::cout << this->birthday_date 							 << std::endl;
	std::cout << "\033[1;33mFavourite_meal:\033[0m" 			 << std::endl;
	std::cout << this->favourite_meal  							 << std::endl;
	std::cout << "\033[1;33mUnderwear_color:\033[0m" 			 << std::endl;
	std::cout << this->underwear_color 							 << std::endl;
	std::cout << "\033[1;33mDarkest_secret:\033[0m" 			 << std::endl;
	std::cout << this->darkest_secret  							 << std::endl;
}

std::string		Contact::getIndex(void)
{
	return this->index;
}
