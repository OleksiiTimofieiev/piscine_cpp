/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Account.class.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/18 17:16:15 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/18 17:16:17 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <iomanip>
#include <ctime>
#include "Account.class.hpp"

int			Account::_nbAccounts = 0;
int			Account::_totalAmount = 0;
int			Account::_totalNbDeposits = 0;
int			Account::_totalNbWithdrawals = 0;

void			Account::_displayTimestamp(void) {
	std::time_t	t;
	std::tm		*gmt;

	t = std::time(NULL);
	gmt = std::gmtime(&t);

	std::cout << "[" << gmt->tm_year + 1900
	<< std::setfill('0') << std::setw(2) << gmt->tm_mon + 1
	<< std::setfill('0') << std::setw(2) << gmt->tm_mday << "_"
	<< std::setfill('0') << std::setw(2) << gmt->tm_hour
	<< std::setfill('0') << std::setw(2) << gmt->tm_min
	<< std::setfill('0') << std::setw(2) << gmt->tm_sec << "] ";
}

Account::Account(int initial_deposit)
{
	_accountIndex = _nbAccounts;
	_amount = initial_deposit;
	_nbDeposits = 0;
	_nbWithdrawals = 0;

	_displayTimestamp();
	std::cout << "index:" << _accountIndex<< ";amount:" << _amount << ";created" << std::endl;

	_nbAccounts++;
	_totalAmount += initial_deposit;
}

Account::~Account(void)
{
	_displayTimestamp();
	std::cout << "index:" << _accountIndex << ";amount:" << _amount << ";closed" << std::endl;
}

void		Account::displayAccountsInfos(void)
{
	_displayTimestamp();
	std::cout   << "accounts:" << _nbAccounts << ";total:" << _totalAmount << ";deposits:" << _totalNbDeposits
				<< ";withdrawals:" << _totalNbWithdrawals << std::endl;
}


void		Account::displayStatus(void) const
{
	_displayTimestamp();
	std::cout 	<< "index:" << _accountIndex<< ";amount:" << _amount<< ";deposits:" 
				<< _nbDeposits<< ";withdrawals:" << _nbWithdrawals << std::endl;
}

void		Account::makeDeposit(int deposit)
{
	_displayTimestamp();
	std::cout << "index:" << _accountIndex << ";p_amount:" << _amount << ";deposit:" << deposit;

	_amount += deposit;
	_nbDeposits++;

	std::cout << ";amount:" << _amount << ";nb_deposits:" << _nbDeposits << std::endl;
}

bool		Account::makeWithdrawal(int withdrawal)
{
	_displayTimestamp();
	std::cout << "index:" << _accountIndex << ";p_amount:" << _amount << ";withdrawal:";

	if (_amount < withdrawal)
	{
		std::cout << "refused" << std::endl;
		return (false);
	}

	_amount -= withdrawal;
	_nbWithdrawals++;

	std::cout << withdrawal
			<< ";amount:" << _amount
			<< ";nb_withdrawals:" << _nbWithdrawals
			<< std::endl;
	return (true);
}


