/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   megaphone.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/18 08:53:13 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/18 08:55:34 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

void	change_the_register(char *str)
{
	while (*str)
	{
		*str = std::toupper(*str);
		str++;
	}
}

int		main(int argc, char **argv)
{
	int limit;

	limit = 1;	
	if (argc > 1)
	{
		while (limit < argc)
		{
			change_the_register(argv[limit]);
			std::cout << argv[limit++];
		}
		std::cout << std::endl;
	}
	else
		std::cout << "* LOUD AND UNBEARABLE FEEDBACK NOISE *" << std::endl;
}
