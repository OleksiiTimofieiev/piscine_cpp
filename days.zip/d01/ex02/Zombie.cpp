/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 15:34:01 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 15:34:06 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

Zombie::Zombie(){}

Zombie::Zombie(std::string name, std::string type) : _name(name), _type(type) {
	// std::cout << "Zombie is ready to kill:" << this->_name << std::endl;
	// std::cout << "Zombie`s killer type:" << this->_type << std::endl;

}
	
Zombie::~Zombie(){
	// std::cout << "Zombie has gone for some beer:" << this->_name << std::endl;
}

void	Zombie::announce(void) const
{
	std::cout << '<' << this->_name << ' ' << '(' << this->_type << ')' << '>' << " Braiiiiiiinnnssss..." << std::endl;
}