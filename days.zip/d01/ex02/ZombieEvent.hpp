/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieEvent.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 15:34:58 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 10:25:34 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIEEVENT_HPP
#define ZOMBIEEVENT_HPP

#include <iostream>
#include "Zombie.hpp"

class ZombieEvent
{

private:
	std::string _type;
public:
	ZombieEvent();
	~ZombieEvent();
	void	setZombieType (std::string type);
	Zombie* newZombie(std::string name);
	Zombie* randomChump();
};

#endif

