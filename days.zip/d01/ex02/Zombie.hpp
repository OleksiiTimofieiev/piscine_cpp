/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 15:34:29 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 10:27:08 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_HPP
#define ZOMBIE_HPP

#include <iostream>

class Zombie
{

private:
	std::string _name;
	std::string	_type;	
public:
	
	// system block;
	Zombie();
	Zombie(std::string name, std::string type);
	~Zombie();
	// methods block
	void	announce(void) const;
	void	randomChump(void);
};

#endif
