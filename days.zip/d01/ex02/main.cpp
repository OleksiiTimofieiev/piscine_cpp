/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 15:35:08 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 10:25:28 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"
#include "ZombieEvent.hpp"

int		main(void)
{
	// simple constructor;
	Zombie Deadpool = Zombie("Deadpool", "qutie");
	Zombie Godzilla = Zombie("Godzilla", "blablablah");

	// setter;
	ZombieEvent duo = ZombieEvent();
	duo.setZombieType("with Cola");

	// newZombie method;
	Zombie *DoubleCheeseburger = duo.newZombie("DoubleCheeseburger");

	// randomChump method;
	Zombie *Random1 = duo.randomChump();
	Zombie *Random2 = duo.randomChump();
	Zombie *Random3 = duo.randomChump();
	Zombie *Random4 = duo.randomChump();


	// simple constructor;
	Deadpool.announce();
	Godzilla.announce();

	// newZombie method;
	DoubleCheeseburger->announce();

	// randomChump method;
	Random1->announce();
	Random2->announce();
	Random3->announce();
	Random4->announce();

	delete DoubleCheeseburger;
	delete Random1;
	delete Random2;
	delete Random3;
	delete Random4;

	// system("leaks a.out");
}
