/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieEvent.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 15:34:43 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 10:25:38 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ZombieEvent.hpp"

ZombieEvent::ZombieEvent(){}
	
ZombieEvent::~ZombieEvent(){}

void	ZombieEvent::setZombieType(std::string type)
{
	this->_type = type;
}

Zombie  *ZombieEvent::newZombie(std::string name)
{
	Zombie *sample = new Zombie(name, this->_type);

	return (sample);
}

Zombie  *ZombieEvent::randomChump(void)
{
	int i;
	int j;

	i = 0;
	std::string name_random = "evil_stuff";

	while (i < 10)
	{
		j = 'A' + random () % 26;
		name_random[i] = j;
		i++;
	}

	Zombie *sample = new Zombie(name_random, this->_type);

	return (sample);
}

