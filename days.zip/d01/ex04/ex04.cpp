/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ex04.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 19:12:45 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 21:35:24 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

void	byPtr(std::string const * str)
{
	std::cout << *str << std::endl;
}

void	byRef(std::string const & str)
{
	std::cout << str << std::endl;
}

int		main(void)
{
	std::string unicorn = "HI THIS IS BRAIN";

	std::string* unicorn_p = &unicorn;
	std::string& unicorn_ref = unicorn;

	byPtr(unicorn_p);
	byRef(unicorn_ref);

	return (0);
}
