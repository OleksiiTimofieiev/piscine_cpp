/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 22:04:25 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 10:59:18 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>
#include <string>

int		main(int argc, char const *argv[])
{
    std::string         s1;
    std::string         s2;
    std::string         buffer;
    std::string         output;
    std::string         filename;

    if (argc == 4)
    {
        s1 = argv[2];
        s2 = argv[3];

        filename = argv[1];

        output = filename + ".replace";

        std::ifstream   readFile(filename);

        if (readFile.fail())
        {
            std::cout << "Error" << std::endl;
            exit(1); // exit with error;
        }

        std::ofstream    outFile(output);

        if (outFile.fail())
        {
            std::cout << "Error" << std::endl;
            exit(1); // exit with error;
        }
        while (std::getline(readFile, buffer))
        {
            while (buffer.find(s1) != std::string::npos)
                buffer.replace(buffer.find(s1), s1.length(), s2); // cool method for the replacing;

            outFile << buffer;
            outFile << std::endl;
        }
        if (buffer == "")
            outFile << std::endl;
        readFile.close();
        outFile.close();
    }
    else
        std::cout << "Please, enter the data: file, s1, s2";
    return (0);
}
