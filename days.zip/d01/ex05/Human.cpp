/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Human.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 19:23:15 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 19:23:15 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Human.hpp"

Human::Human(void) : brain()
{
}

Human::~Human(void)
{
}

std::string		Human::identify(void) const
{
	return this->brain.identify();
}

Brain			Human::getBrain(void)
{
	return this->brain;
}

