/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Human.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 19:23:23 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 19:23:24 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUMAN_H
# define HUMAN_H

# include <iostream>
# include <string>
# include "Brain.hpp"

class Human {
	public:
		Human(void);
		~Human(void);

		Brain const		brain;

		std::string		identify(void) const;
		Brain 			getBrain(void);
};

#endif
