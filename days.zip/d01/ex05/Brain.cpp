/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Brain.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 19:22:54 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 19:22:56 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Brain.hpp"

	Brain::Brain() 
	{
			void const *address = static_cast<const void*>(this);
			std::stringstream address2;
			address2 << address;
			this->_address = address2.str();
	};
	Brain::~Brain() {};

	std::string Brain::identify(void) const{

	return (this->_address);


}
