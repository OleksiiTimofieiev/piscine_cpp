/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 14:56:04 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 14:56:05 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Pony.hpp"

void	ponyOnTheStack(void)
{
	Pony Instance = Pony("Fireballs !!!");
}

void	ponyOnTheHeap(void)
{
	Pony* Instance = new Pony("Flash !!!");

	delete Instance;
}

int		main(void)
{
	ponyOnTheStack();
	ponyOnTheHeap();

	return (0);
}
