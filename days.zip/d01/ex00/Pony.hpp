/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Pony.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 14:55:36 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 10:24:53 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PONY_HPP_CPP
#define PONY_HPP_CPP

#include <iostream>

class Pony {

private:
	std::string	_magic;
public:
	Pony( std::string magic );	

	~Pony( void );
};

#endif
