/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Pony.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 14:55:49 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 14:55:51 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

#include "Pony.hpp"

Pony::Pony(std::string magic) : _magic(magic) {
	std::cout << "Pony has been created with magic: " << this->_magic << std::endl;
}

Pony::~Pony(void) {
	std::cout << "Pony was killed :((((" << std::endl;
}
