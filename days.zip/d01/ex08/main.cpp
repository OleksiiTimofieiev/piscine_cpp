/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 22:12:58 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 21:40:41 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Human.hpp"

int	main(void)
{
	Human HelloKitty;

	HelloKitty.action("rangedAttack", "Gagnant");
	HelloKitty.action("meleeAttack", "Gagnant");
	HelloKitty.action("intimidatingShout", "Gagnant");
	return (0);
}
