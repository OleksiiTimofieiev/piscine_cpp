/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Weapon.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 20:02:42 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 20:02:46 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WEAPON_HPP
#define WEAPON_HPP

#include <iostream>

class Weapon
{

private:
	std::string type;
public:
	Weapon();
	Weapon(std::string weapon);
	~Weapon();
	std::string const & getType() const;
	void	setType(std::string);
	
};






















#endif
