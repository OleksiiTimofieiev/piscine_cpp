/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanA.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 20:03:28 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 17:43:40 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HumanA_HPP
#define HumanA_HPP

#include <iostream>

#include "Weapon.hpp"


class HumanA
{
private:
	std::string _name;
	Weapon & _weapon;

public:
	// HumanA();
	~HumanA();
	HumanA(std::string name, Weapon & weapon);
	void	attack(void);

	
};






































#endif
