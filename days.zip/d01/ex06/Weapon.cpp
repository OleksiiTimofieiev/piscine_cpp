/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Weapon.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 20:02:27 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 20:02:28 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Weapon.hpp"

Weapon::Weapon() {};
Weapon::~Weapon() {};
Weapon::Weapon(std::string weapon) : type(weapon) {
	// std::cout << this->type << std::endl;
}
void	Weapon::setType( std::string var ) { this->type = var; }

std::string		const & Weapon::getType() const{
	return this->type;
}
