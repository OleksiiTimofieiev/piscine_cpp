/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 20:04:08 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 20:04:09 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */




#ifndef HumanB_HPP
#define HumanB_HPP

#include <iostream>

#include "Weapon.hpp"


class HumanB
{

private:
	Weapon *_weapon;
	std::string _name;

public:
	HumanB();
	~HumanB();
	HumanB(std::string name, Weapon & weapon);
	HumanB(std::string name);
	void	attack(void);
	void	setWeapon(Weapon & weapon);

	
};






































#endif

