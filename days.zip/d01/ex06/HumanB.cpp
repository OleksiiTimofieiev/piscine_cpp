/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 20:03:41 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 10:54:44 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "HumanB.hpp"

HumanB::HumanB() {};
HumanB::~HumanB() {};

HumanB::HumanB(std::string name, Weapon & weapon) 
{
	this->_name = name;
	this-> _weapon = &weapon;
}

HumanB::HumanB(std::string name) : _name(name) {}

void	HumanB::attack(void)
{
	std::cout << this->_name << " attacks with his " << this->_weapon->getType() << std::endl;
}

void	HumanB::setWeapon(Weapon & weapon)
{
	this->_weapon = &weapon;
}