/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieHorde.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 17:50:20 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/19 17:50:21 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"
#include "ZombieHorde.hpp"

ZombieHorde::ZombieHorde(int N){

	this->hord = new Zombie[N];
	this->quantity = N;
}
ZombieHorde::~ZombieHorde(){
	delete [] this->hord;
}

void ZombieHorde::announce(){
	int i = 0;
	while (i < this->quantity)
		this->hord[i++].announce();
}
