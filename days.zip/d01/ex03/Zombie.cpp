/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otimofie <otimofie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/19 17:49:49 by otimofie          #+#    #+#             */
/*   Updated: 2018/06/20 17:17:04 by otimofie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

Zombie::Zombie() {
	int i;
	int j;

	i = 0;
	std::string name_random = "evil_stuff";

	while (i < 10)
	{
		j = 'A' + random () % 26;
		name_random[i] = j;
		i++;
	}
	this->_name = name_random;
	// std::cout << "Zombie is ready to kill:" << this->_name << std::endl;
	// std::cout << "Zombie`s killer type:" << this->_type << std::endl;

}
	
Zombie::~Zombie(){
	std::cout << "Zombie has gone for some beer:" << this->_name << std::endl;
}

void	Zombie::announce(void) const
{
	std::cout << '<' << this->_name << '>' << " Braiiiiiiinnnssss..." << std::endl;
}
