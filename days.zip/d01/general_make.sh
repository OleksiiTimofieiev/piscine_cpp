for d in */; do
    echo "$d"
	make fclean -C $d
done
