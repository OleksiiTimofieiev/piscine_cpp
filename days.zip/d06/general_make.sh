for d in */; do
    echo "\033[1;32m$d\033[0m"
	make -C $d
done

/Applications/Sublime\ Text.app/Contents/SharedSupport/bin/subl ./