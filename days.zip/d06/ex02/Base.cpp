

#include "Base.hpp"

Base::~Base(void)
{}
