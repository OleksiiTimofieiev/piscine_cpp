for d in */; do
    echo "\033[1;32m$d\033[0m"
	make fclean -C $d
done
